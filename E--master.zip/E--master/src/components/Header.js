import React, { useState } from "react";
import { FaSearch, FaUser, FaShoppingCart } from "react-icons/fa";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext"; // Import AuthContext for authentication
import { useNavigate } from "react-router-dom"; // Import useNavigate for navigation
import "./Header.css";


function Header({ searchQuery, setSearchQuery }) {
  const { getCartCount } = useCart(); // Get cart count from context
  const { isAuthenticated, logout } = useAuth(); // Get auth context for authentication state
  const navigate = useNavigate(); // Initialize navigate for routing
  const [activeDropdown, setActiveDropdown] = useState(null);

  const menuData = {
    sanpham: {
      title: "Sản phẩm",
      items: [
        {
          title: "Theo thương hiệu",
          subitems: ["Dell", "HP", "Asus", "Lenovo", "Acer"],
        },
        {
          title: "Mẫu Laptop",
          subitems: [
            "Laptop Gaming",
            "Laptop Văn Phòng",
            "Laptop AI",
            "Laptop Mỏng Nhẹ",
          ],
        },
        {
          title: "Mức giá",
          subitems: [
            "Dưới 10 triệu",
            "10-20 triệu",
            "20-30 triệu",
            "Trên 30 triệu",
          ],
        },
      ],
    },
    phukien: {
      title: "Phụ kiện",
      items: [
        {
          title: "Phụ kiện laptop",
          subitems: ["Balo & Túi", "Chuột", "Adapter", "Lót chuột"],
        },
      ],
    },
    flashSale: {
      title: "Flash Sale",
      items: [
        {
          title: "Khuyến mãi hot",
          subitems: ["Giảm 30%", "Combo tiết kiệm", "Quà tặng khủng"],
        },
        {
          title: "Theo danh mục",
          subitems: [
            "Laptop Gaming",
            "Laptop Văn Phòng",
            "Laptop AI",
            "Laptop Mỏng Nhẹ",
          ],
        },
      ],
    },
    linkkienLaptop: {
      title: "Link kiện máy tính",
      items: [
        {
          title: "Ổ cứng (SSD)",
          subitems: ["120GB", "128GB", "256GB", "512GB", "1TB"],
        },
        {
          title: "Ổ cứng (HDD)",
          subitems: ["256GB", "512GB", "1TB"],
        },
        {
          title: "RAM",
          subitems: ["4GB", "8GB", "16GB", "32GB", "64GB", "128GB"],
        },
      ],
    },
    DichVu: {
      title: "Dịch vụ",
      items: [
        {
          title: "Bảo hành & Sửa chữa",
          subitems: ["Chính sách bảo hành", "Đặt lịch", "Kiểm tra bảo hành"],
        },
        {
          title: "Hỗ trợ khách hàng",
          subitems: ["Tư vấn mua hàng", "Hỗ trợ kỹ thuật", "Trả góp"],
        },
      ],
    },
  };

  const handleUserIconClick = () => {
    if (isAuthenticated) {
      // Nếu đã đăng nhập, đăng xuất
      logout();
    } else {
      // Nếu chưa đăng nhập, chuyển hướng đến trang đăng nhập
      navigate("/login");
    }
  };

  return (
    <>
      
      <header className="header">
        <div className="logo" onClick={() => navigate("/")}>
          <img src="/logo-laptoplcvn1.jpg" alt="LAPTOP.VN" />
        </div>

        <nav className="main-nav">
          {Object.entries(menuData).map(([key, menu]) => (
            <div
              key={key}
              className="nav-item"
              onMouseEnter={() => setActiveDropdown(key)}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="nav-link">{menu.title}</button>
              {activeDropdown === key && (
                <div className="dropdown-menu">
                  <div className="dropdown-content">
                    {menu.items.map((category, index) => (
                      <div key={index} className="dropdown-category">
                        <h3>{category.title}</h3>
                        <ul>
                          {category.subitems.map((item, itemIndex) => (
                            <li key={itemIndex}>
                              <a
                                href={`/${key}/${item
                                  .toLowerCase()
                                  .replace(/ /g, "-")}`}
                              >
                                {item}
                              </a>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </nav>

        <div className="header-actions">
          <div className="search-bar">
            <input
              type="text"
              placeholder="Tìm kiếm sản phẩm..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <FaSearch className="search-icon" />
          </div>

          <div
            className="user-icon-wrapper"
            onClick={handleUserIconClick}
            title={isAuthenticated ? "Đăng xuất" : "Đăng nhập"}
          >
            <FaUser className="user-icon" />
          </div>

          <div
            className="cart-icon-wrapper"
            onClick={() => navigate("/cart")} // Navigate to the cart page
          >
            <FaShoppingCart className="cart-icon" />
            <span className="cart-count">{getCartCount()}</span>
          </div>
        </div>
      </header>
    </>
  );
}

export default Header;

import React, { useState, useEffect, useCallback } from 'react';
import { products } from '../data/products';
import './ProductList.css';
import Filter from './Filter';
import { Link } from 'react-router-dom'; // Import Link từ react-router-dom

function ProductList({ searchQuery }) {
  const [filters, setFilters] = useState({
    cpu: {},
    priceRange: {},
    cpuTech: {},
    ram: {},
    screen: {},
    storage: {},
    graphics: {},
    price: null,
  });

  const [filteredProducts, setFilteredProducts] = useState(products);

  // Sử dụng useCallback để memoize các hàm lọc
  const filterByPriceSlider = useCallback(
    (product) => {
      const priceFilter = filters.price;
      if (priceFilter == null || typeof priceFilter !== 'number') return true;
      return product.salePrice <= priceFilter;
    },
    [filters.price]
  );

  const filterByPriceRange = useCallback(
    (product) => {
      const filterObj = filters.priceRange;
      if (!filterObj || Object.keys(filterObj).length === 0) return true;

      const priceInMillions = product.salePrice / 1000000;

      return Object.keys(filterObj).some((range) => {
        const [minStr, maxStr] = range.split('-');
        const min = parseFloat(minStr);
        const max = parseFloat(maxStr);
        if (isNaN(min) || isNaN(max)) return false;
        return priceInMillions >= min && priceInMillions <= max;
      });
    },
    [filters.priceRange]
  );

  const filterBySpec = useCallback(
    (product, filterKey) => {
      const filterObj = filters[filterKey];
      if (!filterObj || Object.keys(filterObj).length === 0) return true;

      return Object.keys(filterObj).some((filterValue) => {
        return product.specs?.some((spec) => {
          if (!spec.text) return false;
          return spec.text.toLowerCase().includes(filterValue.toLowerCase());
        });
      });
    },
    [filters]
  );

  // Thêm hàm lọc theo searchQuery
  const filterBySearchQuery = useCallback(
    (product) => {
      if (!searchQuery || searchQuery.trim() === '') return true;
      return product.name.toLowerCase().includes(searchQuery.toLowerCase());
    },
    [searchQuery]
  );

  const filterProducts = useCallback(
    (products) => {
      return products.filter((product) => {
        if (typeof product.salePrice !== 'number') return false;

        if (!filterByPriceSlider(product)) return false;
        if (!filterByPriceRange(product)) return false;
        if (!filterBySpec(product, 'cpu')) return false;
        if (!filterBySpec(product, 'ram')) return false;
        if (!filterBySpec(product, 'screen')) return false;
        if (!filterBySpec(product, 'storage')) return false;
        if (!filterBySpec(product, 'graphics')) return false;
        if (!filterBySearchQuery(product)) return false; // Áp dụng lọc theo searchQuery

        return true;
      });
    },
    [
      filterByPriceSlider,
      filterByPriceRange,
      filterBySpec,
      filterBySearchQuery,
    ]
  );

  useEffect(() => {
    console.log('Filters updated:', filters);
    setFilteredProducts(filterProducts(products));
  }, [filters, filterProducts]);

  return (
    <div className="product-list-page">
      <Filter filters={filters} setFilters={setFilters} />

      <div className="product-list-container">
        <h1>Danh sách sản phẩm ({filteredProducts.length})</h1>
        {filteredProducts.length === 0 ? (
          <p>Không tìm thấy sản phẩm</p>
        ) : (
          <div className="product-grid">
            {filteredProducts.map((product) => (
              <Link style={{ textDecoration: 'none' }}
                key={product.id}
                to={`/product/${product.id}`} 
                className="product-card-link"
              >
                <div className="product-card">
                  {product.installment && (
                    <div className="installment-badge">{product.installment}</div>
                  )}

                  <div className="product-top">
                    <div className="product-image-container">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="product-image"
                      />
                    </div>

                    <div className="specs-container">
                      {product.specs?.map((spec, index) => (
                        <div key={index} className="spec-item">
                          {spec.icon && (
                            <span className="spec-icon">
                              <spec.icon size={20} />
                            </span>
                          )}
                          <span>{spec.text}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="product-bottom">
                    <div className="price-container">
                      <div className="original-price">
                        {product.originalPrice.toLocaleString()}đ
                        <span className="discount-percent">
                          -{product.discountPercent}%
                        </span>
                      </div>
                      <div className="sale-price">
                        {product.salePrice.toLocaleString()}đ
                      </div>
                      <div className="discount-amount">
                        Giảm {product.discount.toLocaleString()}đ
                      </div>
                      <div className="time-left">{product.timeLeft}</div>
                    </div>

                    <h3 className="product-name">{product.name}</h3>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default ProductList;

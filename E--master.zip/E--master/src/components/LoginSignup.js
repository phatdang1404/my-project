import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext'; // Import AuthContext for authentication
import './Login.css'; // Import CSS để thêm hiệu ứng xoay

function LoginSignup() {
  const [isLogin, setIsLogin] = useState(true);
  const { login } = useAuth(); // Thêm logic login từ AuthContext
  const { register } = useAuth(); // Thêm logic register từ AuthContext nếu có

  const toggleForm = () => {
    setIsLogin(!isLogin);
  };

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    const email = e.target.elements.email.value;
    const password = e.target.elements.password.value;
    login(email, password);
  };

  const handleSignupSubmit = (e) => {
    e.preventDefault();
    const username = e.target.elements.username.value;
    const email = e.target.elements.email.value;
    const password = e.target.elements.password.value;
    register(username, email, password);
  };

  return (
    <div className={`auth-container ${isLogin ? '' : 'flip'}`}>
      <div className="form-wrapper">
        <div className="form-container login-container">
          <form className="form" onSubmit={handleLoginSubmit}>
            <h2>Đăng nhập</h2>
            <input type="email" name="email" placeholder="Email" required />
            <input type="password" name="password" placeholder="Password" required />
            <button type="submit">Đăng nhập</button>
            <p className="toggle-text" onClick={toggleForm}>
              Bạn chưa có tài khoản? Đăng ký
            </p>
          </form>
        </div>
        <div className="form-container signup-container">
          <form className="form" onSubmit={handleSignupSubmit}>
            <h2>Đăng ký</h2>
            <input type="text" name="username" placeholder="Username" required />
            <input type="email" name="email" placeholder="Email" required />
            <input type="password" name="password" placeholder="Password" required />
            <button type="submit">Đăng ký</button>
            <p className="toggle-text" onClick={toggleForm}>
              Bạn đã có tài khoản? Đăng nhập
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

export default LoginSignup;

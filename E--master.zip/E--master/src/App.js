import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import { AuthProvider } from './context/AuthContext'; // Import AuthProvider
import Header from './components/Header';
import Banner from './components/Banner';
import ProductList from './components/ProductList';
import ProductDetail from './components/ProductDetail';
import Footer from './components/Footer';
import { products } from './data/products';
import Checkout from './components/Checkout';
import OrderSuccess from './components/OrderSuccess';
import Cart from './components/Cart';
import LoginSignup from './components/LoginSignup';

function App() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <Router>
      <AuthProvider>
        <CartProvider>
          <div className="app">
            <Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
            <Banner />
            <Routes>
              <Route path="/"element={<ProductList searchQuery={searchQuery} />} />

              <Route path="/product/:id" element={<ProductDetail products={products} />} />

              <Route path="/checkout" element={<Checkout />} />

              <Route path="/order-success" element={<OrderSuccess />} />

              <Route path="/cart" element={<Cart />} />

              <Route path="/login" element={<LoginSignup />} />

            </Routes>
            <Footer />
          </div>
        </CartProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
